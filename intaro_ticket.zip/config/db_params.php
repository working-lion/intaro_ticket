<?php

return array(
    'host' => 'p326820.mysql.ihc.ru',
    'dbname' => 'p326820_ticket',
    'user' => 'p326820_ticket',
    'password' => 'p326820_ticket'
);