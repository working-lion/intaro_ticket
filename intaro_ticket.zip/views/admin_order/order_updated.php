<!-- head -->
<?php include ROOT . '/template/head.php';?>
<?php //require_once(ROOT . '/template/head.php');?>
<body>
<!-- header -->
<?php include ROOT . '/template/header.php';?>
<div class="container">
    <h2>Заказ успешно отредактирован!</h2>
    <p class="ok_message"><i class="fa fa-check-square-o" aria-hidden="true">
    </i>Номер заказа: <?php echo $orderId;?></p>
</div>

<!-- footer -->
<?php include ROOT . '/template/footer.php';?>
</body>
</html>
