<?php

//запускаем удаление неоплаченных заказов
Order::checkOrderList();
