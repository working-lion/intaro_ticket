<footer>
    <div class="container">
        <p>Copyright (c) 2017 tichet.смотримсайт.рф. All rights reserved.</p>
    </div>
</footer>

<!--<script type="text/javascript" src="/js/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="/js/theme.js"></script>-->