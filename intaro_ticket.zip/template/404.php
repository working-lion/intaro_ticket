<!-- head -->
<?php include ROOT . '/template/head.php';?>
<?php //require_once(ROOT . '/template/head.php');?>
<body>
<!-- header -->
<?php include ROOT . '/template/header.php';?>
<div class="container">
    <p class="error">Страница не найдена :(</p>
</div>
<!-- footer -->
<?php include ROOT . '/template/footer.php';?>
</body>
</html>
