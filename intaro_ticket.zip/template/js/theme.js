$(document).ready(function(){
    $('.plaseListCheckbox').click(function(){
        $(this).toggleClass('checked');
    });
});
