<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta name="keywords" content="" />
        <meta name="description" content="" />
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <title>Ticket48</title>
        <!--Пути до картинок и файла стилей-->
        <?php
            $img_path = $_SESSION["img_path"];
            $css_path = $_SESSION["css_path"];
        ?>
        <link href="<?php echo $css_path . 'style.css'; ?>" rel="stylesheet" type="text/css"/>
        <link href="<?php echo $css_path . 'font-awesome.min.css'; ?>" rel="stylesheet" type="text/css"/>
        <!--<link href="../css/style.css" rel="stylesheet" type="text/css"/>
        <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css"/>-->
    </head>
